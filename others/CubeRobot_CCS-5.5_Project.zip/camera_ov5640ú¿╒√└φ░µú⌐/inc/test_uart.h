#include "types.h"

#ifndef _Hardserial_H
#define _Hardserial_H

void DebugUartInit(void);

void DebugPrintf(UINT8 *pData);


#endif


